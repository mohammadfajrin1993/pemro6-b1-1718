/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package praktikumenam;

/**
 *
 * @author hp
 */
public class Vehicle {
    public Vehicle(){
        System.out.println("This is vehicle constructor");
    }
           int ccNumber;
          //method dibawah
          void brake(){
              System.out.println("Brake");
          }
          
          void turnLeft(){
              System.out.println("Turn Left");
          }
          void turnRight(){
              System.out.println("Turn Right");
          }
}
